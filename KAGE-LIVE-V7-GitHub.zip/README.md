# KAGE LIVE V7 — Anime Avatar Studio

## Archivos
- `index.html`: página para publicar junto a `avatar.webp` en GitHub Pages.
- `avatar.webp`: el personaje masculino anime de la imagen seleccionada.
- `KAGE-LIVE-ABRIR.html`: versión autónoma para probar localmente sin imágenes externas.

## Cómo usar
1. Abre la página. El personaje se ve de inmediato, sin descargar ningún recurso externo.
2. En **Expresiones**, prueba emociones y acciones. En **Regalos**, escribe el nombre del espectador y toca los regalos simulados.
3. Para abrir la boca según tu voz, ve a **Voz y audio > Activar micrófono** y concede permiso. Necesita HTTPS o contexto seguro y un navegador compatible.
4. **Android, compartiendo la pantalla del mismo móvil:** pulsa **Modo LIVE**. Oculta todos los botones, el panel y el menú de control, y solicita pantalla completa. Solo comparte pantalla cuando ya estés en esa vista. Para salir, toca tres veces seguidas la esquina superior izquierda. Si vas a necesitar acciones manuales durante el directo, necesitarás un segundo dispositivo o una integración adicional.
5. **PC con OBS / TikTok LIVE Studio:** pulsa **Abrir salida LIVE** para crear una segunda pestaña/ventana sin controles. En OBS captura esa ventana o la URL `index.html?screen=live`, manteniendo Estudio separado. Las acciones se sincronizan entre pestañas del mismo origen/navegador mediante BroadcastChannel/localStorage. Cuando reproduzcas una escena o agradecimiento, la pantalla limpia lo mostrará. Si capturas el audio, revisa el sistema de audio de la herramienta de streaming.
6. Si seleccionas **Pronunciar agradecimientos**, usa la voz de síntesis de Android o del navegador, que puede variar según dispositivo.

## Publicar en GitHub Pages
1. Crea un repositorio, por ejemplo `kage-live`.
2. Sube `index.html` y `avatar.webp` a la raíz de la rama `main`.
3. Configuración del repositorio > Pages > Build and deployment > Deploy from a branch > `main` / `/ (root)`.
4. Abre la URL HTTPS de GitHub Pages generada. La URL suele ser `https://USUARIO.github.io/kage-live/` (sustituir con tu usuario real).

## Límites reales y privacidad
- **La página NO está conectada a TikTok.** Los regalos y agradecimientos incluidos son simulaciones que tú activas. Recibir automáticamente regalos, comentarios o donaciones requiere una integración de eventos y permisos/servidor, no está incluida.
- **No es Live2D ni seguimiento facial real.** La boca responde a la voz, las expresiones son efectos visuales y las acciones son animaciones sobre el personaje ilustrado. No son deformaciones profesionales del cuerpo o la cara.
- **Modo LIVE oculta únicamente los controles de KAGE LIVE**: no puede ocultar elementos del sistema Android, interfaz de TikTok, notificaciones, señales del sistema ni gestos capturados por TikTok. Activa **No molestar** para mayor privacidad.
- **En un solo teléfono**, compartir pantalla de la página LIVE significa que no puedes tocar el panel de control privado simultáneamente sin cambiar de pantalla. Los micrófonos usados por TikTok y el navegador pueden competir según Android; pruébalo antes de emitir en público.
- La webcam no se activa ni se utiliza. El audio del micrófono se procesa en memoria con Web Audio API y no se envía a servidor desde esta página.
- El streaming de video hacia TikTok depende de las funciones que tenga habilitadas tu cuenta y de las opciones de emisión disponibles en tu móvil/PC.
